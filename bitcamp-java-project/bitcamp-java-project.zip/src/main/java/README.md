# 변경 내역
- build.gradle 변경
- /WEB-INF/spring/application-context.xml 추가
- /WEB-INF/spring/json-servlet.xml 추가
- /WEB-INF/spring/dispatcher-servlet.xml 변경
- /WEB-INF/web.xml 변경 
- bitcam.java106.pms.web.json 패키지 생성
- *.json.BoardController 클래스 추가
- webapp/html/board/list.html 생성 
- webapp/html/board/form.html 생성
- webapp/html/header.html 생성
- webapp/html/header.js 생성   

## javascript 라이브러리 정의
- webapp/html2/js/bitcamp.js 생성

